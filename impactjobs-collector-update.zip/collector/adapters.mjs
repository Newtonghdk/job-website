import * as cheerio from 'cheerio';
import { plain,httpUrl,isoDate } from './core.mjs';

export function lever(data,source) {
  if(!Array.isArray(data)) throw Error('Lever response must be an array');
  return data.map(j=>({sourceId:j.id,title:j.text,company:source.company,location:[j.categories?.location,...(j.categories?.allLocations||[])].filter(Boolean).filter((x,i,a)=>a.indexOf(x)===i).join('; '),description:[j.description,...(j.lists||[]).map(l=>`<h3>${l.text}</h3>${l.content}`),j.additional].filter(Boolean).join('\n'),postedDate:j.createdAt?new Date(j.createdAt).toISOString():'',jobType:j.categories?.commitment,workMode:j.workplaceType,sourceUrl:j.hostedUrl,applyUrl:j.applyUrl,salary:j.salaryRange?`${j.salaryRange.currency||''} ${j.salaryRange.min??''}–${j.salaryRange.max??''} ${j.salaryRange.interval||''}`:'',about:j.additionalPlain}));
}
export function greenhouse(data,source) {
  if(!Array.isArray(data.jobs)) throw Error('Greenhouse response missing jobs');
  return data.jobs.map(j=>({sourceId:j.id,title:j.title,company:source.company,location:j.location?.name,description:j.content,sourceUrl:j.absolute_url,applyUrl:j.absolute_url,reviewNotes:'Greenhouse updated_at is not an original posting date.'}));
}
export function jsonJobs(data,source) {
  const list=source.itemsPath?source.itemsPath.split('.').reduce((o,k)=>o?.[k],data):Array.isArray(data)?data:data.jobs;
  if(!Array.isArray(list)) throw Error('JSON source needs an array or jobs array; configure itemsPath if required');
  const mapping=source.fieldMap||{};
  return list.map(j=>Object.keys(mapping).length?Object.fromEntries(Object.entries(mapping).map(([to,path])=>[to,String(path).split('.').reduce((o,k)=>o?.[k],j)])):j);
}
function strings(value) { return Array.isArray(value)?value.map(strings).filter(Boolean).join('; '):typeof value==='object'&&value?value.name||value.value||'':value||''; }
export function jsonLd(html,url,source) {
  const $=cheerio.load(html);const nodes=[];
  function walk(x) { if(Array.isArray(x)) x.forEach(walk); else if(x&&typeof x==='object') {if([x['@type']].flat().includes('JobPosting')) nodes.push(x); if(x['@graph'])walk(x['@graph']); if(x.itemListElement)walk(x.itemListElement); if(x.item)walk(x.item);} }
  $('script[type="application/ld+json"]').each((_,el)=>{try{walk(JSON.parse($(el).text()));}catch{/* Some sites include unrelated broken JSON-LD. */}});
  return nodes.map(j=>{
    const places=[j.jobLocation].flat().filter(Boolean).map(p=>{const a=p.address||{};return [a.addressLocality,a.addressRegion,strings(a.addressCountry)].filter(Boolean).join(', ');});
    if(j.jobLocationType==='TELECOMMUTE') places.push('Remote',strings(j.applicantLocationRequirements));
    const salary=j.baseSalary, amount=salary?.value;
    return {sourceId:strings(j.identifier)||j.url||url,title:j.title,company:j.hiringOrganization?.name||source.company,description:j.description,location:places.filter(Boolean).join('; '),postedDate:j.datePosted,expiryDate:j.validThrough,sourceUrl:j.url||url,applyUrl:j.url||url,jobType:strings(j.employmentType),skills:strings(j.skills),qualifications:strings(j.qualifications),responsibilities:strings(j.responsibilities),experience:strings(j.experienceRequirements),companyWebsite:j.hiringOrganization?.sameAs,logo:j.hiringOrganization?.logo,workMode:j.jobLocationType==='TELECOMMUTE'?'Remote':'',salary:salary?`${salary.currency||''} ${typeof amount==='object'?amount.value??`${amount.minValue??''}–${amount.maxValue??''}`:amount??''} ${amount?.unitText||''}`:''};
  });
}

// Selector-configured public pages: no login, browser automation, or CAPTCHA bypass.
export function htmlJob(html,url,source) {
  const structured=jsonLd(html,url,source); if(structured.length)return structured;
  if(!source.selectors) throw Error('No JobPosting JSON-LD; configure CSS selectors for this source');
  const $=cheerio.load(html), s=source.selectors;
  const raw={sourceUrl:url,company:source.company};
  for(const [field,selector] of Object.entries(s)) {
    const el=$(selector).first();
    raw[field]=['applyUrl','companyWebsite','logo'].includes(field)?httpUrl(el.attr(field==='logo'?'src':'href'),url):['description','skills','qualifications','responsibilities','benefits','howToApply','about'].includes(field)?el.html()||'':el.text().trim();
  }
  if(!raw.title||!raw.description)throw Error('Configured title/description selector returned empty content');
  return [raw];
}
export function csrbox(html,url,source) {
  const $=cheerio.load(html);
  const main=$('.col-lg-8').filter((_,e)=>$(e).find('h3.mb-3').length).first();
  const title=main.find('h3.mb-3').first().text().trim();
  const description=main.children('div.mb-5').not('.d-flex').first().html()||'';
  if(!title||plain(description).length<100)throw Error('CSRBOX detail layout changed: title or description missing');
  const text=plain(description),label=name=>text.match(new RegExp(`(?:^|\\n)${name}\\s*:\\s*([^\\n]+)`,'i'))?.[1]?.trim()||'';
  const summary=$('h4').filter((_,e)=>$(e).text().trim()==='Job Summary').parent();
  const apply=$('h4').filter((_,e)=>$(e).text().trim().toLowerCase()==='how to apply').parent();
  const how=plain(apply.html());
  const summaryText=plain(summary.html());
  const company=label('organi[sz]ation')||text.match(/(?:^|\n)About (CSRBOX|BharatCares)/i)?.[1]||source.company;
  const applyUrl=apply.find('a[href]').toArray().map(e=>httpUrl($(e).attr('href'),url)).find(Boolean)||'';
  return [{sourceId:new URL(url).searchParams.get('id')||new URL(url).pathname.match(/_(\d+)\/?$/)?.[1]||url,title,company,
    description:description+(how?`<h3>How to apply</h3>${apply.html()}`:''),sourceUrl:url,applyUrl,
    location:summaryText.match(/Location:\s*([^\n]+)/i)?.[1]||main.find('span.text-truncate').first().text(),
    expiryDate:summaryText.match(/Deadline:\s*([^\n]+)/i)?.[1]||'',salary:label('salary')||label('CTC'),
    jobType:label('employment type')||label('job type'),experience:label('experience'),howToApply:how,
    email:how.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i)?.[0]||'',
    reviewNotes:'Collected from the employer careers page. Verify the application endpoint before publishing.'}];
}
export function rss(xml,source) {
  const $=cheerio.load(xml,{xml:true});const result=[];
  $('item,entry').each((_,e)=>{const el=$(e),link=el.children('link').first();const url=httpUrl(link.attr('href')||link.text(),source.url);const desc=el.children().filter((_,x)=>['description','content','content:encoded','summary'].includes(x.tagName)).last();result.push({sourceId:el.children('guid,id').first().text()||url,title:el.children('title').text(),description:desc.text(),sourceUrl:url,applyUrl:url,postedDate:el.children('pubDate,published').first().text(),company:source.company,location:source.location||'',reviewNotes:'RSS/Atom feed: verify full description and closing date on linked employer page.'});});
  if(!result.length&&!$('rss,feed').length)throw Error('Response is not an RSS/Atom feed');
  return result;
}
export async function collectSource(source,client,config,knownUrls=new Set()) {
  if(source.adapter==='lever')return {jobs:lever(await client.json(source.url),source),errors:[]};
  if(source.adapter==='greenhouse')return {jobs:greenhouse(await client.json(source.url),source),errors:[]};
  if(source.adapter==='json')return {jobs:jsonJobs(await client.json(source.url),source),errors:[]};
  if(source.adapter==='rss') {const r=await client.get(source.url,true);return {jobs:rss(r.text,source),errors:[]};}
  if(!['html','jsonld','csrbox'].includes(source.adapter))throw Error(`Unsupported adapter: ${source.adapter}; no scraping attempted`);
  const first=await client.get(source.url,true), $=cheerio.load(first.text);
  const linkSelector=source.linkSelector||(source.adapter==='csrbox'?'a[href*="job-detail_"],a[href*="career_detail"]':'');
  const urls=linkSelector?[...new Set($(linkSelector).toArray().map(el=>httpUrl($(el).attr('href'),first.url)).filter(Boolean))]:[first.url];
  if(linkSelector&&!urls.length)throw Error('No job detail links found; source layout may have changed');
  const sameHost=urls.filter(u=>new URL(u).hostname.replace(/^www\./,'')===new URL(first.url).hostname.replace(/^www\./,''));
  const limit=source.maxDetails||config.maxDetailsPerSource||15;
  // Rotate rechecks, but prefer unseen detail URLs. Covers long lists across hourly runs.
  const rotation=Math.floor(Date.now()/3600000)%Math.max(sameHost.length,1);
  const ordered=[...sameHost.slice(rotation),...sameHost.slice(0,rotation)].sort((a,b)=>Number(knownUrls.has(a))-Number(knownUrls.has(b)));
  const jobs=[],errors=[];
  for(const url of ordered.slice(0,limit)) {
    try {
      const page=url===first.url?first:await client.get(url,true);
      const rows=source.adapter==='csrbox'?csrbox(page.text,page.url,source):htmlJob(page.text,page.url,source);
      if(!rows.length)throw Error('No JobPosting data found');jobs.push(...rows);
    } catch(error) {errors.push(`${url}: ${error.message}`);}
  }
  return {jobs,errors,deferred:Math.max(0,urls.length-limit)};
}

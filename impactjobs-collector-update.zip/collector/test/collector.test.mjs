import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Deduper,canonical,normalize,eligible,isoDate,plain } from '../core.mjs';
import { lever,greenhouse,jsonLd,rss,htmlJob } from '../adapters.mjs';
import { configuredSources,Sheets,columnName } from '../sheets.mjs';
import { planJobs } from '../run.mjs';
import { publicAddress } from '../http.mjs';

const source={name:'Employer',company:'Foundation',url:'https://example.org/jobs',category:'NGO'};
const raw={sourceId:'123',title:'Sr. Programme Manager',company:'Foundation',location:'New Delhi',description:'<h2>Responsibilities</h2><p>Manage education programmes, coordinate partner organisations, maintain budgets and prepare reports for funders.</p>',applyUrl:'https://example.org/jobs/123',sourceUrl:'https://example.org/jobs/123',expiryDate:'2027-01-01'};
const config={maxNewJobs:100,locationPattern:'delhi|india'};
const now=new Date('2026-09-15T00:00:00Z');
const job=()=>normalize(raw,source,now);

test('canonical URL removes tracking but retains requisition query',()=>{
  assert.equal(canonical('https://www.example.org/job?id=42&utm_source=x#apply'),'example.org/job?id=42');
  assert.notEqual(canonical('https://x.org/?id=42'),canonical('https://x.org/?id=43'));
});
test('cross-source duplicates preserve one main entry',()=>{
  const first={...job(),ID:'existing-id',Status:'Published',_row:8};
  const plan=planJobs([{raw:{...raw,sourceId:'board-789',applyUrl:'https://board.org/789',sourceUrl:'https://board.org/789',title:'Senior Programme Manager',location:'Delhi'},source:{...source,name:'Board'}}],[first],config,now);
  assert.equal(plan.added.length,0);assert.equal(plan.updates[0].ID,'existing-id');assert.equal(plan.updates[0].Status,'Published');
});
test('state annotations do not create duplicate multi-city jobs; deadline conflict is noted',()=>{
  const first={...job(),Location:'Delhi NCR / Kolkata',_row:5};
  const plan=planJobs([{raw:{...raw,location:'(Delhi), Kolkata (West Bengal)',expiryDate:'2027-02-01'},source:{...source,name:'Other'}}],[first],config,now);
  assert.equal(plan.added.length,0);assert.match(plan.updates[0]['Review Notes'],/Duplicate source Other reports Expiration Date/);
});
test('same run deduplicates across sources and reruns',()=>{
  const inputs=[{raw,source},{raw:{...raw,sourceId:'other'},source:{...source,name:'Other'}}];
  const first=planJobs(inputs,[],config,now);assert.equal(first.added.length,1);
  const second=planJobs(inputs,first.added,config,now);assert.equal(second.added.length,0);
});
test('different jobs using same generic application form stay separate',()=>{
  const a={...job(),'Apply URL':'https://forms.gle/shared'};
  assert.equal(new Deduper([a]).find({...a,ID:'second',Title:'Finance Officer','Source Job ID':'999','Source URL':'https://example.org/jobs/999'}),null);
});
test('distinct requisitions with same title on one source stay separate',()=>{
  const a={...job(),'Apply URL':'https://forms.gle/shared'};
  assert.equal(new Deduper([a]).find({...a,'Source Job ID':'456','Source URL':'https://example.org/jobs/456'}),null);
});
test('different cities are not merged based solely on employer and title',()=>{
  const a=job();assert.equal(new Deduper([a]).find({...a,Source:'Other','Source Job ID':'9',Location:'Mumbai','Source URL':'https://other.org/9','Apply URL':'https://other.org/9'}),null);
});
test('reopened posting with new requisition and later date is retained',()=>{
  const old={...job(),'Expiration Date':'2026-08-01'};
  const next={...job(),'Source Job ID':'next','Source URL':'https://example.org/jobs/next','Date Posted':'2026-09-01'};
  assert.equal(new Deduper([old]).find(next),null);
});
test('hidden/rejected jobs do not return as fresh Drafts',()=>{
  const a={...job(),Status:'Hidden'};assert.ok(new Deduper([a]).find(job()));
});
test('normalization never invents posted date, compensation or status',()=>{
  const a=job();assert.equal(a.Status,'Draft');assert.equal(a['Date Posted'],'');assert.equal(a.Salary,'');assert.match(a['Review Notes'],/not supplied/);
});
test('expired, incomplete and wrong location jobs are filtered',()=>{
  assert.match(eligible({...job(),'Expiration Date':'2026-08-01'},config,source,'2026-09-15'),/Expired/);
  assert.match(eligible({...job(),'Job Description':''},config,source),/Incomplete/);
  assert.match(eligible({...job(),Location:'London'},config,source),/location/);
});
test('ambiguous dates stay blank rather than choosing a wrong month',()=>{assert.equal(isoDate('10/11/2026'),'');assert.equal(isoDate('30 Sep, 2026'),'2026-09-30');});
test('HTML preserves bullets/headings while removing scripts',()=>{assert.equal(plain('<h2>Skills</h2><ul><li>Reporting</li></ul><script>bad()</script>'),'Skills\n• Reporting');});
test('JSON-LD graph extracts actual JobPosting fields only',()=>{
  const x=jsonLd('<script type="application/ld+json">'+JSON.stringify({'@graph':[{'@type':'Organization',name:'Ignore'},{'@type':'JobPosting',title:'Officer',description:'Work description',hiringOrganization:{name:'Real NGO'},jobLocation:{address:{addressLocality:'Delhi',addressCountry:'India'}},datePosted:'2026-09-01',validThrough:'2026-09-30',identifier:{value:'req-1'}}]})+'</script>','https://example.org/job',source);
  assert.equal(x.length,1);assert.equal(x[0].company,'Real NGO');assert.equal(x[0].sourceId,'req-1');assert.equal(x[0].location,'Delhi, India');
});
test('Lever extracts complete lists and benefits',()=>{
  const [x]=lever([{id:'1',text:'Officer',categories:{location:'India',commitment:'Full-time'},description:'Overview',lists:[{text:'Responsibilities',content:'<li>Teach</li>'}],additional:'Benefits',hostedUrl:'https://x.org/1',applyUrl:'https://x.org/1/apply'}],source);
  assert.match(x.description,/Responsibilities/);assert.match(x.description,/Benefits/);assert.equal(x.jobType,'Full-time');
});
test('Greenhouse updated date is not used as posted date',()=>{const [x]=greenhouse({jobs:[{id:1,title:'Manager',updated_at:'2026-09-15',content:'Text',location:{name:'India'}}]},source);assert.equal(x.postedDate,undefined);});
test('RSS and Atom parse descriptions but do not invent employers',()=>{
  const [x]=rss('<rss><channel><item><title>Job</title><link>https://x.org/job</link><description><![CDATA[<p>Details</p>]]></description></item></channel></rss>',{url:'https://x.org/feed'});assert.equal(x.description,'<p>Details</p>');assert.equal(x.company,undefined);
  const [a]=rss('<feed><entry><title>Job</title><link href="https://x.org/job"/><summary>Details</summary><id>123</id></entry></feed>',source);assert.equal(a.sourceId,'123');
});
test('HTML fallback must have explicit selectors',()=>{
  assert.throws(()=>htmlJob('<h1>Job</h1>','https://example.org',source),/configure CSS/);
  const [x]=htmlJob('<h1>Job</h1><article><p>Detailed job</p></article>','https://example.org',{...source,selectors:{title:'h1',description:'article'}});assert.equal(x.title,'Job');
});
test('Active No disables a configured source; directory Yes does not enable scraping',()=>{
  const result=configuredSources({sources:[{name:'CSRBOX',enabled:true}]},{rows:[{'Source Name':'CSRBOX',Active:'No'},{'Source Name':'LinkedIn',Active:'Yes',URL:'linkedin.com'}]});assert.equal(result.sources.length,0);assert.equal(result.skipped.length,1);
});
test('invalid options disable the matching source',()=>{
  const r=configuredSources({sources:[{name:'CSRBOX',enabled:true}]},{rows:[{'Source Name':'CSRBOX',Active:'Yes','Collector Enabled':'Yes','Collector Adapter':'html','Options JSON':'{broken'}]});assert.equal(r.sources.length,0);
});
test('private network sources cannot be fetched',()=>{for(const a of ['127.0.0.1','10.0.0.1','169.254.169.254','::1','::ffff:127.0.0.1','192.168.1.3'])assert.equal(publicAddress(a),false);assert.equal(publicAddress('8.8.8.8'),true);});
test('spreadsheet column naming works beyond Z',()=>{assert.equal(columnName(23),'X');assert.equal(columnName(26),'AA');assert.equal(columnName(37),'AL');});
test('Sheet write is strings-only and does not overwrite published rows',async()=>{
  const api=new Sheets('fake');const old={...job(),ID:'old',Status:'Published',_row:1};const added={...job(),ID:'new',Title:'=IMPORTXML("bad")'};
  let sent;
  api.api=async(id,p,b)=>{sent=b;return {};};api.read=async()=>({rows:[old,added]});
  const {JOB_HEADERS}=await import('../core.mjs');
  await api.commit({id:'sheet',tab:'Jobs',props:{sheetId:0,gridProperties:{rowCount:100,columnCount:27}},headers:JOB_HEADERS,values:[JOB_HEADERS,[]],meta:{sheets:[{properties:{sheetId:0,title:'Jobs'}}]}},{added:[added],updates:[]},[]);
  const write=sent.requests.find(r=>r.updateCells?.start.rowIndex===2);
  assert.equal(write.updateCells.rows[0].values[1].userEnteredValue.stringValue,added.Title);assert.equal(write.updateCells.rows[0].values[1].userEnteredValue.formulaValue,undefined);
  assert.equal(sent.requests.some(r=>r.updateCells?.start.rowIndex===1),false);
});

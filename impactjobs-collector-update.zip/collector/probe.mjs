// Read-only source diagnostics. Does not use credentials or write Google Sheets.
import * as cheerio from 'cheerio';
const urls=process.argv.slice(2);
for(const url of urls) {
  try {
    const r=await fetch(url,{signal:AbortSignal.timeout(20000)});const body=await r.text();
    console.log(url,r.status);
    if(url.includes('api.github.com')) {const j=JSON.parse(body);console.log({private:j.private,branch:j.default_branch});continue;}
    const $=cheerio.load(body);
    console.log('Relevant links', $('a[href]').toArray().map(e=>$(e).attr('href')).filter(h=>/career|job-detail|greenhouse|lever|recruitee|bamboo|workable|forms\.gle/.test(h)).slice(0,35));
    if(url.endsWith('/career/')) console.log('First job markup',$('h5.mb-3').first().parent().parent().parent().html());
    console.log('Headings', $('h1,h2,h3,h4,h5').toArray().map(e=>({tag:e.tagName,text:$(e).text().trim().slice(0,130),class:$(e).attr('class'),parent:$(e).parent().attr('class')})).slice(-45));
    if(/career_detail|job-detail/.test(url)) {
      console.log('Body fragment', $('h3').first().parent().parent().parent().parent().html()?.slice(0,14000));
      console.log('Summary markup',$('h4').first().parent().html()?.slice(0,5000));
      if(url.includes('ngobox.org'))console.log('NGOBOX structure',$('h1').first().parent().html()?.slice(0,6500));
    }
  }catch(e){console.log(e.message);process.exitCode=1;}
}

import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebClient } from './http.mjs';
import { Sheets,configuredSources } from './sheets.mjs';
import { normalize,eligible,Deduper,keys,canonical } from './core.mjs';
import { collectSource } from './adapters.mjs';

export function planJobs(rawJobs,existing,config,now=new Date()) {
  const deduper=new Deduper(existing),added=[],updates=new Map(),counts={},decisions=[];
  for(const {raw,source} of rawJobs) {
    const c=counts[source.name]??={added:0,duplicates:0,filtered:0,deferred:0};
    const job=normalize(raw,source,now),reason=eligible(job,config,source);
    if(reason){c.filtered++;decisions.push({source:source.name,title:job.Title,result:reason});continue;}
    const match=deduper.find(job);
    if(match) {
      c.duplicates++;
      const main=match.job;
      const warnings=new Set(String(main['Review Notes']||'').split('\n').filter(Boolean));
      for(const field of ['Expiration Date','Salary','Experience'])if(main[field]&&job[field]&&main[field]!==job[field])warnings.add(`Duplicate source ${source.name} reports ${field}: ${job[field]}; retained main value ${main[field]}. Review the source.`);
      main['Review Notes']=[...warnings].join('\n').slice(0,45000);
      main['Last Seen']=now.toISOString(); main['Collector Keys']=JSON.stringify([...new Set([...keys(main),...keys(job)])]);deduper.add(main);
      if(Number.isInteger(main._row))updates.set(main._row,main);
      decisions.push({source:source.name,title:job.Title,result:'Duplicate skipped',mainId:main.ID,reason:match.reason});continue;
    }
    if(added.length>=config.maxNewJobs){c.deferred++;continue;}
    added.push(job);deduper.add(job);c.added++;
  }
  return {added,updates:[...updates.values()],counts,decisions};
}

export async function main() {
  const root=path.dirname(fileURLToPath(import.meta.url));
  const config=JSON.parse(await fs.readFile(path.join(root,'config.json'),'utf8'));
  const dry=process.argv.includes('--dry-run')||process.env.COLLECTOR_DRY_RUN==='true';
  const selected=process.argv.find(a=>a.startsWith('--source='))?.slice(9);
  const service=process.env.GOOGLE_SERVICE_ACCOUNT_JSON;
  const sheets=service?await Sheets.connect(service):null;
  if(!dry&&!sheets)throw Error('Live collection requires GOOGLE_SERVICE_ACCOUNT_JSON. You can run npm run preview without credentials.');
  let existing=[],sources=config.sources.filter(s=>s.enabled),skipped=[],snapshot;
  if(sheets) {
    const sourceSheet=await sheets.read(config.sourcesSpreadsheetId,config.sourcesTab);
    ({sources,skipped}=configuredSources(config,sourceSheet));
    snapshot=await sheets.read(config.jobsSpreadsheetId,config.jobsTab);existing=snapshot.rows;
  }else {
    const file=process.argv.find(a=>a.startsWith('--existing='))?.slice(11);
    if(file)existing=JSON.parse(await fs.readFile(file,'utf8'));
    console.log('Preview without Google credentials: using repository source configuration; no Sheet writes.');
  }
  if(selected)sources=sources.filter(s=>s.name.toLowerCase()===selected.toLowerCase());
  if(!sources.length)throw Error('No enabled configured sources');
  // Rotate sources when the configured list grows beyond one run capacity.
  const offset=Math.floor(Date.now()/3600000)%sources.length;
  sources=[...sources.slice(offset),...sources.slice(0,offset)].slice(0,config.maxSourcesPerRun);
  const client=new WebClient(config),incoming=[],status=[];
  const knownUrls=new Set(existing.map(r=>r['Source URL']).filter(Boolean));
  for(const source of sources) {
    try {
      const result=await collectSource(source,client,config,knownUrls);
      for(const raw of result.jobs)incoming.push({raw,source});
      status.push({name:source.name,result:result.errors.length?'Partial':'OK',found:result.jobs.length,details:[...result.errors,result.deferred?`${result.deferred} detail pages deferred by per-run limit`:''].filter(Boolean).join('\n')});
      console.log(`${source.name}: ${result.jobs.length} vacancies read, ${result.errors.length} detail errors`);
    }catch(error){status.push({name:source.name,result:'Error',found:0,details:error.message});console.log(`${source.name}: ${error.message}`);}
  }
  // Re-read immediately before writing so manual review/status changes during collection survive.
  if(sheets){snapshot=await sheets.read(config.jobsSpreadsheetId,config.jobsTab);existing=snapshot.rows;}
  const plan=planJobs(incoming,existing,config),time=new Date().toISOString();
  const logs=status.map(s=>[time,s.name,s.result,s.found,plan.counts[s.name]?.added||0,plan.counts[s.name]?.duplicates||0,plan.counts[s.name]?.filtered||0,s.details]);
  if(skipped.length)logs.push([time,'Source configuration','Needs setup',0,0,0,0,skipped.join('\n')]);
  const summary={time,dryRun:dry,added:plan.added.length,duplicates:Object.values(plan.counts).reduce((n,c)=>n+c.duplicates,0),filtered:Object.values(plan.counts).reduce((n,c)=>n+c.filtered,0),sources:status,unconfiguredSources:skipped,requests:client.requests};
  await fs.mkdir(path.join(root,'output'),{recursive:true});
  await fs.writeFile(path.join(root,'output','latest.json'),JSON.stringify({summary,jobs:plan.added,decisions:plan.decisions},null,2));
  if(!dry)await sheets.commit(snapshot,plan,logs);
  console.log(JSON.stringify(summary,null,2));
  if(process.env.GITHUB_STEP_SUMMARY)await fs.appendFile(process.env.GITHUB_STEP_SUMMARY,`## Job collection ${dry?'preview':''}\n\nAdded: ${summary.added}; duplicates skipped: ${summary.duplicates}; filtered: ${summary.filtered}.\n\n${status.map(s=>`- ${s.name.replace(/[<>]/g,'')}: ${s.result}, ${s.found} read`).join('\n')}\n\nNew jobs are Drafts. Review Collector Log in Google Sheets.\n`);
  if(status.some(s=>s.result==='Error'||s.result==='Partial'))process.exitCode=1;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(error=>{console.error(error.message);process.exitCode=1;});

import robotsParser from 'robots-parser';
import { lookup } from 'node:dns/promises';
import { isIP } from 'node:net';

export const USER_AGENT='ImpactJobsCollector/1.0 (+https://github.com/Newtonghdk/job-website)';
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
export function publicAddress(ip) {
  if (isIP(ip)===6) return /^2|^3/.test(ip); // Global unicast only; no mapped IPv4 or local IPv6.
  const p=ip.split('.').map(Number);
  return p.length===4 && ![0,10,127].includes(p[0]) && p[0]<224 && !(p[0]===169&&p[1]===254) && !(p[0]===172&&p[1]>=16&&p[1]<=31) && !(p[0]===192&&(p[1]===168||p[1]===0)) && !(p[0]===100&&p[1]>=64&&p[1]<=127) && !(p[0]===198&&[18,19].includes(p[1]));
}
export class WebClient {
  constructor(config) { this.timeout=config.requestTimeoutMs||20000; this.deadline=Date.now()+(config.runBudgetSeconds||360)*1000; this.robots=new Map(); this.last=new Map(); this.requests=0; }
  async validate(value) {
    const u=new URL(value);
    if (!['http:','https:'].includes(u.protocol)||u.username||u.password||(u.port&&!['80','443'].includes(u.port))) throw Error('Only public HTTP(S) sources on standard ports are supported');
    const addresses=await lookup(u.hostname,{all:true});
    if (!addresses.length||addresses.some(a=>!publicAddress(a.address))) throw Error('Non-public source address rejected');
    return u;
  }
  async request(value,{html=false,redirects=0}={}) {
    if (Date.now()>this.deadline) throw Error('Run budget reached; remaining sources deferred');
    if (redirects>5) throw Error('Too many redirects');
    const u=await this.validate(value);
    if (html) await this.allowed(u.href);
    const wait=Math.max(0,1100-(Date.now()-(this.last.get(u.host)||0)));
    if (wait) await sleep(wait);
    this.last.set(u.host,Date.now()); this.requests++;
    const response=await fetch(u,{headers:{'User-Agent':USER_AGENT,Accept:'application/json, text/html, application/xml;q=0.9, */*;q=0.5'},signal:AbortSignal.timeout(this.timeout),redirect:'manual'});
    if ([301,302,303,307,308].includes(response.status)) { const loc=response.headers.get('location'); await response.body?.cancel(); if(!loc) throw Error('Redirect without Location'); return this.request(new URL(loc,u).href,{html,redirects:redirects+1}); }
    if (Number(response.headers.get('content-length'))>5000000) { await response.body?.cancel(); throw Error('Source exceeds 5 MB limit'); }
    let size=0; const parts=[];
    for await (const chunk of response.body||[]) { size+=chunk.length; if(size>5000000) throw Error('Source exceeds 5 MB limit'); parts.push(chunk); }
    return {status:response.status,url:u.href,text:Buffer.concat(parts).toString('utf8')};
  }
  async allowed(url) {
    const root=new URL(url).origin;
    if (!this.robots.has(root)) {
      const r=await this.request(root+'/robots.txt');
      if(r.status===404||r.status===410) this.robots.set(root,null);
      else if(r.status===200) this.robots.set(root,robotsParser(root+'/robots.txt',r.text));
      else throw Error(`robots.txt returned HTTP ${r.status}; source deferred`);
    }
    const rules=this.robots.get(root);
    if (rules?.isAllowed(url,USER_AGENT)===false) throw Error('robots.txt disallows collection');
    const delay=Number(rules?.getCrawlDelay(USER_AGENT)||0);
    if(delay>10) throw Error('Source crawl delay exceeds run budget; use API or manual import');
    if(delay>1) await sleep(delay*1000);
  }
  async get(url,html=false) { const r=await this.request(url,{html}); if(r.status!==200) throw Error(`Source returned HTTP ${r.status}`); return r; }
  async json(url) { const r=await this.get(url); try{return JSON.parse(r.text);}catch{throw Error('Source did not return valid JSON');} }
}

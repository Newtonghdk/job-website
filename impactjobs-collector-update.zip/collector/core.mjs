import { createHash } from 'node:crypto';
import * as cheerio from 'cheerio';

export const JOB_HEADERS = ['ID','Title','Company','Company Logo','Job Description','Required Skills','What We Offer','Job Type','Urgency','Location','Date Posted','Expiration Date','Salary','Company Founded','Company Phone','Company Email','Company Website','Company Address','Apply URL','Map URL','Source','Status','Category','Experience'];
export const EXTRA_HEADERS = ['Source URL','Source Job ID','Collected At','Last Seen','Review Notes','Work Mode','Qualifications','Responsibilities','How to Apply','About Company','Collector Keys'];
export const SOURCE_HEADERS = ['Collector Adapter','Collector URL','Collector Enabled','Company','Category','Options JSON'];
export const LOG_HEADERS = ['Time (UTC)','Source','Result','Found','Added','Duplicates','Filtered','Details'];

export function plain(html = '') {
  const $ = cheerio.load(String(html));
  $('script,style,noscript,nav,footer').remove();
  $('br').replaceWith('\n');
  $('li').prepend('• ');
  $('p,div,li,h1,h2,h3,h4,h5,h6,section,tr').append('\n');
  return $.root().text().replace(/\u00a0/g,' ').replace(/[ \t]+/g,' ').replace(/ *\n */g,'\n').replace(/\n{3,}/g,'\n\n').trim();
}
export function norm(text = '') {
  return String(text).normalize('NFKC').toLowerCase().replace(/\bsr\.?\b/g,'senior').replace(/\bjr\.?\b/g,'junior').replace(/&/g,' and ').replace(/[^\p{L}\p{N}]+/gu,' ').trim().replace(/\s+/g,' ');
}
export function locationKey(s = '') {
  const normalized=norm(s).replace(/new delhi|delhi ncr/g,'delhi').replace(/bangalore/g,'bengaluru').replace(/gurgaon/g,'gurugram');
  const cities=normalized.match(/\b(?:delhi|mumbai|bengaluru|kolkata|chennai|hyderabad|pune|guwahati|ahmedabad|noida|gurugram|jaipur|lucknow|bhopal|patna|ranchi|kochi|surat|nagpur|bhubaneswar|mysuru|dehradun|raipur|indore|sagar|gwalior|jabalpur|kanpur|agra|hisar|sonipat|pithampur|bokaro|nashik)\b/g);
  // State annotations can differ across boards. Preserve all named cities; never merge on just one overlap.
  return cities?.length?[...new Set(cities)].sort().join('|'):normalized.split(' ').filter(Boolean).sort().join(' ');
}
export function httpUrl(value, base) {
  if (!value) return '';
  try { const u = new URL(String(value),base); return ['http:','https:'].includes(u.protocol) ? u.href : ''; } catch { return ''; }
}
export function canonical(value) {
  if (!httpUrl(value)) return '';
  const u = new URL(value); u.hash = ''; u.hostname = u.hostname.toLowerCase().replace(/^www\./,'');
  for (const k of [...u.searchParams.keys()]) if (/^utm_|^(fbclid|gclid|ref|referrer|source|trackingId)$/i.test(k)) u.searchParams.delete(k);
  u.searchParams.sort();
  return u.hostname + u.pathname.replace(/\/+$/,'') + (u.search ? u.search : '');
}
export function isoDate(value) {
  if (!value) return '';
  const s = String(value).trim();
  // Never convert an ambiguous MM/DD vs DD/MM date silently.
  if (/^\d{1,2}[/-]\d{1,2}[/-]\d{4}$/.test(s)) return '';
  const iso=s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if(iso) {const day=iso[0],d=new Date(day+'T00:00:00Z');return Number.isNaN(d.getTime())||d.toISOString().slice(0,10)!==day?'':day;}
  const hasZone=/\b(?:GMT|UTC)\b|[+-]\d{2}:?\d{2}$|Z$/i.test(s);
  const ms=Date.parse(hasZone?s:s+' GMT');return Number.isNaN(ms)?'':new Date(ms).toISOString().slice(0,10);
}
export function todayIndia(now = new Date()) { return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kolkata',year:'numeric',month:'2-digit',day:'2-digit'}).format(now); }
export function hash(value) { return createHash('sha256').update(value).digest('hex').slice(0,24); }
export function parseKeys(value) { try { const x = JSON.parse(value||'[]'); return Array.isArray(x) ? x.filter(v=>typeof v==='string') : []; } catch { return []; } }

export function keys(job,includeAliases=true) {
  const identity = `${norm(job.Company)}|${norm(job.Title)}`;
  const result = [];
  if (job['Source Job ID'] && job.Source) result.push(`id:${norm(job.Source)}:${job['Source Job ID']}`);
  if (canonical(job['Source URL'])) result.push(`url:${canonical(job['Source URL'])}|${identity}`);
  // Shared Google Forms, email endpoints and careers portals are not unique job IDs.
  if (canonical(job['Apply URL'])) result.push(`apply:${canonical(job['Apply URL'])}|${identity}`);
  if (norm(job.Company) && norm(job.Title) && norm(job.Location)) result.push(`role:${identity}|${locationKey(job.Location)}`);
  return [...new Set([...result,...(includeAliases?parseKeys(job['Collector Keys']):[])])];
}

export function isReopened(old, job) {
  const end = isoDate(old['Expiration Date']), start = isoDate(job['Date Posted']);
  return Boolean(end && start && start > end);
}
export class Deduper {
  constructor(existing=[]) { this.byKey = new Map(); for (const row of existing) this.add(row); }
  add(row) { for (const key of keys(row)) { if (!this.byKey.has(key)) this.byKey.set(key,[]); const list = this.byKey.get(key); if (!list.includes(row)) list.push(row); } }
  find(job) {
    for (const key of keys(job,false)) {
      for (const old of this.byKey.get(key)||[]) {
        if (isReopened(old,job) && !key.startsWith('id:')) continue;
        if (key.startsWith('role:') || key.startsWith('apply:')) {
          // Two requisitions at the same employer may legitimately share a title and form.
          if (norm(old.Source)===norm(job.Source) && old['Source Job ID'] && job['Source Job ID'] && old['Source Job ID']!==job['Source Job ID']) continue;
        }
        return {job:old,reason:key.split(':')[0]};
      }
    }
    return null;
  }
}

export function section(description, names) {
  const lines=description.split('\n'); let collecting=false; const out=[];
  const headings=/^(?:key |essential |preferred |desired )?(?:responsibilities|requirements|qualifications|skills(?: & competencies)?|benefits|what we offer|how to apply|about .+|location(?: & travel)?|equal opportunity|selection process)\s*:?$/i;
  for (const line of lines) {
    if (names.some(name=>new RegExp(`^(?:key |essential |desired )?${name}\\s*:?$`,'i').test(line.trim()))) { collecting=true; continue; }
    if (collecting && headings.test(line.trim())) break;
    if (collecting) out.push(line);
  }
  return out.join('\n').trim();
}

export function normalize(raw, source, now = new Date()) {
  const description = plain(raw.description||'');
  const title=plain(raw.title||''), company=plain(raw.company||source.company||'');
  const sourceUrl=httpUrl(raw.sourceUrl||raw.applyUrl,source.url);
  const applyUrl=httpUrl(raw.applyUrl,sourceUrl)||sourceUrl;
  const sourceId=String(raw.sourceId||canonical(sourceUrl)||hash(`${company}|${title}|${raw.location}`));
  const notes=[raw.reviewNotes||''];
  const end=isoDate(raw.expiryDate), posted=isoDate(raw.postedDate);
  if (!end) notes.push(raw.expiryDate ? 'Closing date could not be parsed; check source.' : 'Closing date not supplied; confirm vacancy remains open.');
  if (!posted) notes.push('Original posting date not supplied.');
  if (!raw.salary) notes.push('Salary not supplied.');
  if (!raw.applyUrl) notes.push('Application button leads to source instructions; verify application method.');
  const experience=raw.experience||[...description.matchAll(/\b\d{1,2}\s*(?:(?:[-–—]|to)\s*\d{1,2}|\+)\s*(?:years|yrs)\b/gi)].map(m=>m[0]).filter((v,i,a)=>a.indexOf(v)===i).join('; ');
  if (experience.includes(';')) notes.push('Multiple experience ranges in source; reviewer must resolve.');
  const fields={
    ID:`auto-${hash(`${source.name}|${sourceId}`)}`,Title:title,Company:company,
    'Company Logo':httpUrl(raw.logo),'Job Description':description,
    'Required Skills':plain(raw.skills||section(description,['skills(?: & competencies)?','skills and competencies'])),
    'What We Offer':plain(raw.benefits||section(description,['benefits','what we offer'])),
    'Job Type':plain(raw.jobType||''),Location:plain(raw.location||''),
    'Date Posted':posted,'Expiration Date':end,Salary:plain(raw.salary||''),
    'Company Website':httpUrl(raw.companyWebsite),'Company Email':raw.email||'',
    'Apply URL':applyUrl,Source:source.name,Status:'Draft',Category:raw.category||source.category||'Social Impact',Experience:experience,
    'Source URL':sourceUrl,'Source Job ID':sourceId,'Collected At':now.toISOString(),'Last Seen':now.toISOString(),
    'Review Notes':notes.filter(Boolean).join('\n'),'Work Mode':raw.workMode||'',
    Qualifications:plain(raw.qualifications||section(description,['qualifications(?: & skills)?','requirements'])),
    Responsibilities:plain(raw.responsibilities||section(description,['responsibilities'])),
    'How to Apply':plain(raw.howToApply||section(description,['how to apply'])),
    'About Company':plain(raw.about||'')
  };
  fields['Collector Keys']=JSON.stringify(keys(fields));
  for (const [key,value] of Object.entries(fields)) if (String(value).length>45000) { fields[key]=String(value).slice(0,45000); fields['Review Notes']+='\nLong source field truncated at 45,000 characters; use source link.'; }
  return fields;
}

export function eligible(job, config, source, today=todayIndia()) {
  if (!job.Title || !job.Company || !job['Apply URL'] || job['Job Description'].length<100) return 'Incomplete job: needs title, employer, application/source link and description';
  if (job['Expiration Date'] && job['Expiration Date']<today) return 'Expired deadline';
  if (job['Date Posted'] && job['Date Posted']>today) return 'Future posting date; check source';
  const pattern=source.locationPattern??config.locationPattern;
  if (pattern && !new RegExp(pattern,'i').test(job.Location)) return 'Outside configured location filter';
  if (source.keywordPattern && !new RegExp(source.keywordPattern,'i').test(`${job.Title}\n${job['Job Description']}`)) return 'Outside configured subject filter';
  return '';
}

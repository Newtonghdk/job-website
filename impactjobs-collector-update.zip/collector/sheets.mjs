import { createSign } from 'node:crypto';
import { JOB_HEADERS,EXTRA_HEADERS,LOG_HEADERS,SOURCE_HEADERS } from './core.mjs';

export function columnName(n) { let out='';for(n++;n>0;n=Math.floor((n-1)/26))out=String.fromCharCode(65+(n-1)%26)+out;return out; }
const quote=s=>`'${s.replace(/'/g,"''")}'`;
const cells=row=>({values:row.map(value=>({userEnteredValue:{stringValue:String(value??'')}}))});
export class Sheets {
  constructor(token) {this.token=token;}
  static async connect(secret) {
    if(!secret)throw Error('Missing GOOGLE_SERVICE_ACCOUNT_JSON. Complete the one-time setup in COLLECTOR_SETUP.md.');
    let account;try{account=JSON.parse(secret);}catch{throw Error('Service-account secret must contain valid JSON');}
    if(!account.client_email||!account.private_key)throw Error('Service-account JSON is missing client_email or private_key');
    const now=Math.floor(Date.now()/1000), enc=x=>Buffer.from(JSON.stringify(x)).toString('base64url');
    const input=`${enc({alg:'RS256',typ:'JWT'})}.${enc({iss:account.client_email,scope:'https://www.googleapis.com/auth/spreadsheets',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3600})}`;
    const assertion=`${input}.${createSign('RSA-SHA256').update(input).sign(account.private_key,'base64url')}`;
    const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion}),signal:AbortSignal.timeout(20000)});
    if(!r.ok)throw Error(`Google authentication failed (HTTP ${r.status}); check the service-account key`);
    const data=await r.json();if(!data.access_token)throw Error('Google did not issue an access token');
    return new Sheets(data.access_token);
  }
  async api(id,path='',body) {
    const r=await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(id)}${path}`,{method:body?'POST':'GET',headers:{Authorization:`Bearer ${this.token}`,'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(45000)});
    if(!r.ok)throw Error(`Google Sheets HTTP ${r.status}: check API enabled, sheet sharing and quotas`);
    return r.json();
  }
  async read(id,tab) {
    const meta=await this.api(id,'?fields=sheets(properties)');
    const props=meta.sheets.find(s=>s.properties.title===tab)?.properties;
    if(!props)throw Error(`Tab not found: ${tab}`);
    const cap=Math.min(props.gridProperties.rowCount,25000), end=columnName(props.gridProperties.columnCount-1);
    const data=await this.api(id,`/values/${encodeURIComponent(`${quote(tab)}!A1:${end}${cap}`)}?valueRenderOption=FORMATTED_VALUE`);
    const values=data.values||[];
    if(values.length>=cap && cap===25000)throw Error('25,000-row read limit reached; archive old jobs before continuing');
    const width=Math.max(0,...values.map(row=>row.length));
    const headers=Array.from({length:width},(_,i)=>String(values[0]?.[i]??'').trim());
    const named=headers.filter(Boolean);if(new Set(named).size!==named.length)throw Error(`Duplicate header names in ${tab}; fix before collection`);
    return {id,tab,props,meta,values,headers,rows:values.slice(1).map((row,i)=>({...Object.fromEntries(headers.map((h,j)=>[h,row[j]??''])),_row:i+1})).filter(row=>Object.entries(row).some(([k,v])=>k!=='_row'&&k&&v))};
  }
  async commit(snapshot,plan,logs) {
    const {id,props}=snapshot,headers=[...snapshot.headers],requests=[];
    for(const name of JOB_HEADERS)if(!headers.includes(name))throw Error(`Jobs tab missing required header: ${name}`);
    // Keep unnamed existing columns (including the original demo note) untouched.
    const originalCount=headers.length;
    for(const name of EXTRA_HEADERS)if(!headers.includes(name))headers.push(name);
    if(headers.length>props.gridProperties.columnCount)requests.push({appendDimension:{sheetId:props.sheetId,dimension:'COLUMNS',length:headers.length-props.gridProperties.columnCount}});
    if(headers.length>originalCount)requests.push({updateCells:{start:{sheetId:props.sheetId,rowIndex:0,columnIndex:originalCount},rows:[cells(headers.slice(originalCount))],fields:'userEnteredValue'}});
    const last=snapshot.values.length;
    if(last+plan.added.length>props.gridProperties.rowCount)requests.push({appendDimension:{sheetId:props.sheetId,dimension:'ROWS',length:last+plan.added.length-props.gridProperties.rowCount}});
    if(plan.added.length) {
      // Preserve existing cells; initialize only the previously empty destination rectangle.
      const rows=plan.added.map(job=>cells(headers.map(h=>job[h]??'')));
      requests.push({updateCells:{start:{sheetId:props.sheetId,rowIndex:last,columnIndex:0},rows,fields:'userEnteredValue'}});
      requests.push({repeatCell:{range:{sheetId:props.sheetId,startRowIndex:last,endRowIndex:last+rows.length,startColumnIndex:0,endColumnIndex:headers.length},cell:{userEnteredFormat:{verticalAlignment:'TOP',wrapStrategy:'CLIP',textFormat:{fontFamily:'Arial',fontSize:10}}},fields:'userEnteredFormat.verticalAlignment,userEnteredFormat.wrapStrategy,userEnteredFormat.textFormat'}});
    }
    for(const update of plan.updates)for(const name of ['Last Seen','Collector Keys','Review Notes']) requests.push({updateCells:{start:{sheetId:props.sheetId,rowIndex:update._row,columnIndex:headers.indexOf(name)},rows:[cells([update[name]])],fields:'userEnteredValue'}});
    let log=snapshot.meta.sheets.find(s=>s.properties.title==='Collector Log')?.properties;
    if(!log) {const used=new Set(snapshot.meta.sheets.map(s=>s.properties.sheetId));let n=700001;while(used.has(n))n++;log={sheetId:n};requests.push({addSheet:{properties:{sheetId:n,title:'Collector Log',gridProperties:{rowCount:2000,columnCount:8,frozenRowCount:1}}}});requests.push({updateCells:{start:{sheetId:n,rowIndex:0,columnIndex:0},rows:[cells(LOG_HEADERS)],fields:'userEnteredValue'}});}
    if(logs.length)requests.push({appendCells:{sheetId:log.sheetId,rows:logs.map(cells),fields:'userEnteredValue'}});
    if(requests.length)await this.api(id,':batchUpdate',{requests}); // Do not blindly retry an ambiguous write.
    const readback=await this.read(id,snapshot.tab);
    for(const added of plan.added) {const found=readback.rows.find(r=>r.ID===added.ID);if(!found||found.Status!=='Draft'||found.Title!==added.Title)throw Error('Write verification failed; inspect Sheet before rerunning');}
    return readback;
  }
}

export function configuredSources(config,snapshot) {
  const base=config.sources.map(s=>({...s}));const skipped=[];
  for(const row of snapshot.rows) {
    const name=String(row['Source Name']||'').trim();if(!name)continue;
    const index=base.findIndex(s=>s.name.toLowerCase()===name.toLowerCase());
    if(String(row.Active).toLowerCase()!=='yes') {if(index>=0)base[index].enabled=false;continue;}
    if(row['Collector Enabled'] && String(row['Collector Enabled']).toLowerCase()!=='yes') {if(index>=0)base[index].enabled=false;continue;}
    if(row['Collector Adapter']) {
      if(String(row['Collector Enabled']).toLowerCase()!=='yes') {skipped.push(name+': set Collector Enabled to Yes after configuring adapter');if(index>=0)base[index].enabled=false;continue;}
      let opts={};try{opts=JSON.parse(row['Options JSON']||'{}');}catch{skipped.push(name+': invalid Options JSON');if(index>=0)base[index].enabled=false;continue;}
      const allowed=['selectors','linkSelector','locationPattern','keywordPattern','itemsPath','fieldMap','location','maxDetails'];
      const source={...(index>=0?base[index]:{}),...Object.fromEntries(allowed.filter(k=>k in opts).map(k=>[k,opts[k]])),name,adapter:String(row['Collector Adapter']).toLowerCase().trim(),url:row['Collector URL']||row.URL,company:row.Company||(index>=0?base[index].company:''),category:row.Category||(index>=0?base[index].category:'Social Impact'),enabled:true};
      if(!/^https?:\/\//.test(source.url||'')) {skipped.push(name+': Collector URL must include https://');if(index>=0)base[index].enabled=false;continue;}
      if(index>=0)base[index]=source;else base.push(source);
    }else if(index<0)skipped.push(name+': directory/reference only; adapter and collection URL not configured');
  }
  return {sources:base.filter(s=>s.enabled),skipped};
}
